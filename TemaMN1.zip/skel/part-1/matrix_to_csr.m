function [values, colind, rowptr] = matrix_to_csr(A)
  [n,n]=size(A);
  k=1;
  cnt=1;
  for i=1:n
    ok=0;
    for j=1:n
      if A(i,j) != 0
        values(k)=A(i,j);
        colind(k)=j;
        if(ok == 0)
          ok=1;
          rowptr(cnt)=k;
          cnt++;
        endif
        k++;
      endif
    endfor
  endfor
  rowptr(cnt)=k;
endfunction