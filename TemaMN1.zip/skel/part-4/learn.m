function [w] = learn(X, y, lr, epochs)
endfunction
