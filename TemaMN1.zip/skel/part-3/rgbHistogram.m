function [sol] = rgbHistogram(path_to_image, count_bins)
  
  A=imread(path_to_image);
 
  R=A(:,:,1);
  G=A(:,:,2);
  B=A(:,:,3);
  pas=256/count_bins;
  edges=[0:pas:255];
  
  h_R=histc(R,edges);
  h_R=h_R';
  h_R=sum(h_R);
  h_G=histc(G,edges);
  h_G=h_G';
  h_G=sum(h_G);
  h_B=histc(B,edges);
  h_B=h_B';
  h_B=sum(h_B);
  
  sol=[h_R,h_G,h_B];
end