#include <stdlib.h>
#include <stdio.h>

typedef struct node {
    int val;
    struct node *next;
	struct node *prev;
}Node;

typedef struct queue {
    int size;
    Node *head;
    Node *tail;
}Queue;

Node *initNode(int data);
Queue *initQueue();
int isEmpty(Queue *queue);
void enque(Queue *queue, int data);
int deque(Queue *queue);
void freeNode(Node *node);
void freeQueue(Queue *queue);