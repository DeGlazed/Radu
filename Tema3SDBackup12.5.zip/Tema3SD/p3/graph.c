#include <stdlib.h>
#include <stdio.h>
#include "graph.h"
#include "queue.h"

Graph *initGraph(int nodes, int edges, FILE *file)
{
    Graph *graph = malloc(sizeof(Graph));
    graph->adj = buildGraph(nodes,edges,file);
    return graph;
}

Edge **buildGraph(int nodes, int edges, FILE *file)
{
    int i;
    Edge **adj= malloc((nodes + 1) * sizeof(Edge *));
    adj[0] = malloc((nodes + 1) * sizeof(int));
    for (i = 1; i <= nodes; i++) {
        adj[i] = malloc((nodes + 1) * sizeof(int));
        adj[i][0].n = 1; 
        //pozitia de 0 o voi folosi ca un contor de vecini ai nodului i
        //vecinii vor fi de la 1 incolo
        //numarul de vecini va fi contorizar de la 1
        //(nr de vecin = 1 => nu ai niciun vecin)
    }
    for (i = 0; i < edges; i++) {
        int s, d; // sursa si destinatie; citesc laturile si le pun in graf
        fscanf(file, "%d%d", &s, &d);
        adj[s][adj[s][0].n].n=d;
        adj[s][0].n++;
        adj[d][adj[d][0].n].n=s;
        adj[d][0].n++;
    }
    return adj;
}

void freeEdges(int nodes, Edge **adj)
{
    int i;
    for ( i=0; i < nodes; i++){
        free(adj[i]);
    }
    free(adj);
}

void freeGraph(int nodes, Graph *graph)
{
    freeEdges(nodes, graph->adj);
    free(graph);
}
// for debug
void print_graf(int nodes, Graph *graph)
{
    int i, j;
    for (i = 1; i <= nodes; i++) {
        printf("%d : ",i);
        for(j = 1; j < graph->adj[i][0].n; j++) {
            printf("%d ",graph->adj[i][j].n);
        }
        printf("\n");
    }
}

void parcurgere(int nod_inceput, int nod_destinatie, int nodes, Graph *graph, FILE *file)
{
    int i;
    int count = 0;
    int *aparitii = calloc(sizeof(int), (nodes + 1));
    int *parent = calloc(sizeof(int), (nodes + 1));
    int *vizitat = calloc(sizeof(int), (nodes + 1));
    int maxdepth = 32000;
    int lungime;
    bfs_rec(nodes, nod_inceput, graph, vizitat, parent, aparitii, nod_destinatie, &maxdepth, 0  );
    for (i = 1; i <= nodes; i++) {
        if(aparitii[i] == aparitii[nod_inceput]) {
            count++;
        }
    }
    if(maxdepth == 32000) {
        fprintf(file,"0");
    }
    else {
        fprintf(file,"%d ",count);
        for (i = 1; i <= nodes; i++) {
            if(aparitii[i] == aparitii[nod_inceput]) {
                fprintf(file,"%d ",i);
            }
        }

    }
}

// void bfs(Graph *graph, int nodes, int nod_inceput, int nod_final, int *minlenght)
// {
//     Queue *queue = initQueue();
//     int *vizitat = calloc((nodes+1),sizeof(int));
//     vizitat[nod_inceput] = 1;
//     int val,i,k=0,el;
//     enque(queue,nod_inceput);
//     while (isEmpty(queue) == 0) {
//         val=deque(queue);
//         //daca am dat de nodul final, opresc cautarea
//         if(val == nod_final) {
//             break;
//         }
//         for (i = 1; i < graph->adj[val][0].n; i++) {
//             if (vizitat[graph->adj[val][i].n] == 0) {
//                 vizitat[graph->adj[val][i].n] = 1;
//                 enque(queue, graph->adj[val][i].n);
//             }
//         }
//     }
//     *minlenght=k;
// }

void bfs_rec(int nodes, int nod, Graph *graph, int *vizitat, int *parent, int *aparitii, int destinatie, int *maxdepth, int depth)
{
    int i,j,k=1;
    int elem[nodes+1];
    int copyviz[nodes+1], copypar[nodes+1];
    vizitat[nod]=1;
    
    if (all_visited(nodes,vizitat) == 1 || nod == destinatie) {
        if(depth < *maxdepth) {
            //reset aparitii
            for(i = 1; i <= nodes; i++) {
                aparitii[i] = 0;
            }
            *maxdepth = depth;
        }
        i = destinatie;
        while(i != 0) {
            graph->adj[i][parent[i]].n=0;
            aparitii[i]++;
            i=parent[i];
        }
        // //--------------------------
        // printf("%d : ",destinatie);
        // for(i=1;i<=nodes;i++){
        //     printf("%d,",aparitii[i]);
        // }
        // printf("\n");
        // //------------------------------
        return;
    }
    else {
        if(depth > *maxdepth) {
            return;
        }
        for (i = 1; i < graph->adj[nod][0].n; i++) {
            if (vizitat[graph->adj[nod][i].n] != 1) {
                vizitat[graph->adj[nod][i].n] = 1;
                parent[graph->adj[nod][i].n] = nod;
                elem[k]=graph->adj[nod][i].n;
                k++;
            }
        }
        if(k > 1) {
            for( i = 1; i <= nodes; i++) {
                copyviz[i]=vizitat[i];
                copypar[i]=parent[i];
            }
        }
        for ( i = 1; i < k; i++) {
            bfs_rec(nodes, elem[i],graph,vizitat,parent,aparitii,destinatie, maxdepth, depth +1);
            for( j = 1; j <= nodes; j++) {
                vizitat[j]=copyviz[j];
                parent[j]=copypar[j];
            }
        }
    }
    return;
}

int all_visited(int nodes, int *visited)
{
    int i;
    for(i = 1; i <= nodes; i++) {
        if (visited[i] == 0)
            return 0;
    }
    return 1;
}