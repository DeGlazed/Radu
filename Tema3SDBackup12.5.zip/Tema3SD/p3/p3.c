#include <stdlib.h>
#include <stdio.h>
#include "graph.h"



int main(int argc, char **argv)
{
    FILE *fin = fopen(argv[1],"r");
    FILE *fout = fopen(argv[2], "w");
    int nodes, edges, no_query, i, nod_plecare, nod_destinatie;
    fscanf(fin, "%d%d%d", &nodes, &edges, &no_query);
    Graph *graph = initGraph(nodes, edges, fin);
    //print_graf(nodes, graph);
    for (i = 0; i < no_query; i++) {
        // //-----------------------------
        // printf("query %d:\n",i);//debug
        // //-----------------------------
        fscanf(fin, "%d%d", &nod_plecare, &nod_destinatie);
        parcurgere(nod_plecare, nod_destinatie, nodes, graph, fout);
        fprintf(fout,"\n");
        printf("\n");
    }
    freeGraph(nodes,graph);
    fclose(fin);
    fclose(fout);
    return 0;
}