#include <stdlib.h>
#include <stdio.h>

typedef struct edge{
    int n;
}Edge;

typedef struct graph{
    Edge **adj;
}Graph;

Graph *initGraph(int nodes, int edges, FILE *file);
Edge **buildGraph(int nodes, int edges, FILE *file);
void freeEdges(int nodes, Edge **adj);
void freeGraph(int nodes, Graph *graph);
void print_graf(int nodes, Graph *graph);
void parcurgere(int nod_inceput, int nod_destinatie, int nodes, Graph *graph, FILE *file);
void bfs_rec(int nodes, int nod, Graph *graph, int *vizitat, int *parent, int *aparitii, int destinatie, int *maxdepth, int depth);
int all_visited(int nodes, int *visited);
void bfs(Graph *graph, int nodes, int nod_inceput, int nod_final, int *minlenght);