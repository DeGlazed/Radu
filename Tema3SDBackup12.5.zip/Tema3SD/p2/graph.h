#include <stdlib.h>
#include <stdio.h>

typedef struct edge{
    int n;
    int w;
}Edge;

typedef struct graph{
    int no_nodes;
    Edge **adj;
}Graph;

Graph *initGraph(int nodes, int edges, FILE *file);
Edge **buildGraph(int nodes, int edges, FILE *file);
void freeEdges(int nodes, Edge **adj);
void freeGraph(int nodes, Graph *graph);
void print_graf(Graph *graph);
void dijkstra(Graph *graph, int nod, int *cost_final);
void procesare(Graph *graph, int *rep, int nr_rep);