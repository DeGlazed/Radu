#include <unistd.h>
#include <string.h>
#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include <math.h>

static int write_stdout(const char *token, int length)
{
	int rc;
	int bytes_written = 0;

	do {
		rc = write(1, token + bytes_written, length - bytes_written);
		if (rc < 0)
			return rc;

		bytes_written += rc;
	} while (bytes_written < length);

	return bytes_written;
}

int iocla_printf(const char *format, ...)
{
	char *p = malloc(strlen(format)*sizeof(char));
    char *cpf = malloc(strlen(format)*sizeof(char));;
    char *final = calloc(100000,sizeof(char));
    char *s;
    char ch = '%';
    int count = 0;
    int lungime;
    strcpy(p,format);
    strcpy(cpf,format);
    s=p;
//numar cate % sunt pentru a calcula variabila count
    while(cpf = strchr(cpf,ch)) {
        count++;
        cpf += 2;
    }
    va_list args;
    va_start(args,count);
//incep sa parcurg formatul stocat in p (pentru a scapa de const char)
    while(p = strchr(p,ch)) {
        strncat(final,s,p-s);
		//int
        if(*(p+1)=='d'){
            long int n = va_arg(args, int);
            long int p = 1;
            int cnt = 0;
            if(n<0){
                *(final+strlen(final))='-';
                n *= -1;
            }
            if(n < 10){
                *(final+strlen(final))='0'+n;
            }
            else{
                while(p < n){
                    p*=10;
                    cnt++;
                }
                p=p/10;

                while(n) {
                    int u = n/p;
                    *(final+strlen(final))='0'+u;
                    n=n%p;
                    p=p/10;
                    cnt--;
                }
                while (cnt) {
                    *(final+strlen(final))='0';
                    cnt--;
                }
            }
            *(final+strlen(final))='\0';
        }
		//unsigned
        if(*(p+1)=='u'){
            int a = va_arg(args, int);
            unsigned int n = (unsigned int) a;
            long int p = 1;
            int cnt = 0;
            if(n < 10) {
                *(final+strlen(final))='0'+ n ;
            }
            else {
                while(p<n){
                    p*=10;
                    cnt++;
                }
                p=p/10;
                while(n) {
                    int u = n/p;
                    *(final+strlen(final))='0'+u;
                    n=n%p;
                    p=p/10;
                    cnt--;
                }
                while (cnt) {
                    *(final+strlen(final))='0';
                    cnt--;
                }
            }
            *(final+strlen(final))='\0';
        }
		//char
        if(*(p+1)=='c'){
            int c = va_arg(args, int);
            *(final+strlen(final))=c;
        }
		//string
        if(*(p+1)=='s'){
            char *string = va_arg(args, char*);
            strcat(final,string);
        }
		//hex
        if(*(p+1)=='x') {
            long int n = va_arg(args, int);
            long int p = 1;
            int cnt = 0;
            if(n<0){
                n = pow(16,8) + n;
            }
            if(n < 16){
				if(n<10){
                	*(final+strlen(final))='0'+n;
				}
				else{
					char no;
					if(n == 10)
						no = 'a';
					if(n == 11)
						no = 'b';
					if(n == 12)
						no = 'c';
					if(n == 13)
						no = 'd';
					if(n == 14)
						no = 'e';
					if(n == 15)
						no = 'f';
					*(final+strlen(final))=no;
				}
            }
            else{
                while(p < n){
                    p*=16;
                    cnt++;
                }
                p=p/16;

                while(n) {
                    int u = n/p;
					if(u<10){
						*(final+strlen(final))='0'+u;
					}
					else{
						char no;
						if(u == 10)
							no = 'a';
						if(u == 11)
							no = 'b';
						if(u == 12)
							no = 'c';
						if(u == 13)
							no = 'd';
						if(u == 14)
							no = 'e';
						if(u == 15)
							no = 'f';
						*(final+strlen(final))=no;
					}
                    n=n%p;
                    p=p/16;
                    cnt--;
                }
                while (cnt) {
                    *(final+strlen(final))='0';
                    cnt--;
                }
                *(final+strlen(final))='\0';
            }

        }
		// %
        if(*(p+1)=='%'){
            strcat(final,"%");
        }
        count++;
        p+=2;
        s=p;
    }
    //daca mai sunt caractere in format, le concatenez
    if(s){
        strcat(final,s);
    }
    //pun \0 la final de string
	*(final+strlen(final))='\0';
	lungime = strlen(final);
	write_stdout(final,lungime);
    //free
    free(p);
    free(cpf);
    free(final);
	return lungime;
}

// void main()
// {
//     char s[]="%d\n0x%x\n%%%u\n";
//     iocla_printf(s,3,-3,-15);
// }
