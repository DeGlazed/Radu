function [centroids] = clustering_pc(points, NC)
  [n,m]=size(points);
  centroids=zeros(NC,m);
  oldcentroids=zeros(NC,m);
  suma=zeros(NC,m);
  cnt=zeros(NC,m);
  for i=1:NC
    clust=points(i:NC:n,:);
    V=sum(clust);
    [x,y]=size(clust);
    centroids(i,:)=V/x;
  endfor
  
  while (max(norm(centroids-oldcentroids, 2, m)) > 1e-5)
    for i=1:n
      mindist=inf;
      for j=1:NC
        dist=norm(centroids(j,:)-points(i,:));
        if dist<mindist
          mindist=dist;
          cpy=points(i,:);
          k=j;
        endif
      endfor
      suma(k,:)=suma(k,:)+cpy;
      cnt(k,:)++;
    endfor
    oldcentroids=centroids;
    centroids=suma./cnt;
    suma=zeros(NC,m);
    cnt=zeros(NC,m);
  endwhile
endfunction
