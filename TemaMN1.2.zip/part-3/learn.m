function [w] = learn(X, y)
  [n,m]=size(X);
  a=ones(n,1);
  Xp=[X a];
  w=zeros(n+1,1);
  [Q R]=Householder(X);
  b=(Q')*y;
  w=SST(R,b);
 
end
