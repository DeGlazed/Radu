function [H S V]=RGB_to_HSV(R,G,B)
  
  Rp=double(R)/255;
  Gp=double(G)/255;
  Bp=double(B)/255;
  H=zeros(size(R));
  
  Cmax=max(max(Rp,Gp),Bp);
  Cmin=min(min(Rp,Gp),Bp);
  
  V=Cmax;
  D=Cmax-Cmin;
  X=(D(:,:)==0);
  Xp=(D(:,:)!=0);
  Dp=D+X;
  
  a=find(Cmax==Rp);
  b=find(Cmax==Gp);
  c=find(Cmax==Bp);
  
  H(a)=double((mod(((Gp(a)-Bp(a))./Dp(a)),6))*60);
  H(b)=double((((Bp(b)-Rp(b))./Dp(b))+2)*60);
  H(c)=double((((Rp(c)-Gp(c))./Dp(c))+4)*60);
  
  H=H.*Xp;
  
  H=double(H)/360;
  
  
  Xc=(Cmax(:,:)==0);
  Xpc=(Cmax(:,:)!=0);
  Cmax=Cmax+Xc;
  S=D./Cmax;
  S=S.*Xpc;
  
  
  endfunction