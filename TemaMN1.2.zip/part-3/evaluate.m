function [percentage] = evaluate(path_to_testset, w, histogram, count_bins)
  [X,a]=preprocess(path_to_testset,histogram,count_bins);
  w=w(1:3*count_bins);
  y=(w')*X';
  [n,m]=size(y);
  cnt=0;
  for i=1:m
    if (a(i)==1)&&(y(i)>=0)
      cnt++;
    else
      if (a(i)==-1)&&(y(i)<=0)
        cnt++;
      endif
    endif
  endfor
  percentage=(cnt/m)*100;
endfunction