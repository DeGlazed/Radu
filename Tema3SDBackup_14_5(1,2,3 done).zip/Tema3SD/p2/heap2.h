#include <stdlib.h>
#include <stdio.h>

typedef struct heapnode {
    int priroritate;
    int val;
} HeapNode;

typedef struct heap {
    int size; // dimensiunea curenta
    int capacity; //capacitatea maxima a heap-ului
    int *index; // indexul la care este situat un anumit element in heap
    HeapNode *nodes;
} Heap;

Heap *initheap(int maxsize);
int isEmptyHeap(Heap *heap);
int inHeap(Heap *heap, int data);
int parent(int x);
int leftchild(int x);
int rightchild(int x);
void swap(void *a, void *b, size_t len);
void swap_int( int *a, int *b);
void swap_heapnode(HeapNode *a, HeapNode *b);
void siftUp(Heap *heap, int index);
void siftDown(Heap *heap, int index);
int extract_data(Heap *heap);
void insert_data(Heap *heap, int prioritate, int data);
void decreasePriority(Heap *heap, int prioritate, int data);
void freeHeap(Heap *heap);
void print_heap(Heap *heap);