#include <stdlib.h>
#include <stdio.h>
#include "function.h"

int **init_matrix(int N, int M)
{
    int **matrix = malloc(N*sizeof(int*));
    int i;
    for (i = 0; i < N; i++) {
        matrix[i]==calloc(M,sizeof(int));
    }
    return matrix;
}

int **create_matrix(int N, int M, int *pozi, int *pozj, FILE *file)
{
    int i, j;
    int **matrix = init_matrix(N, M);
    for (i = 0; i < N; i++) {
        for (j = 0; j < M; j++) {
            fscanf(file, "%d", &matrix[i][j]);
            if(matrix[i][j] == 2) {
                *pozi = i;
                *pozj = j;
            }
        }
    }
    return matrix;
}

void dfs(int N, int M, int pozi, int pozj, int **matrix, int idx_move, int max_moves, int *moves, int *movei, int *movej, int *cnt)
{
    int i,j;
    if(idx_move == max_moves) {
        *cnt += 1; 
    }
    else {
        i=pozi+movei[moves[idx_move]];
        j=pozj+movej[moves[idx_move]];
        while(matrix[i][j] != 1 && i < N && i >= 0 && j < M && j >= 0) {
            dfs(N,M,i,j,matrix,idx_move+1,max_moves,moves,movei,movej,cnt);
            i=i+movei[moves[idx_move]];
            j=j+movej[moves[idx_move]];
        }
    }

}