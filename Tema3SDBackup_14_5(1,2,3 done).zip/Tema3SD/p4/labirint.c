#include <stdlib.h>
#include <stdio.h>
#include "function.h"

int main(int argc, char **argv)
{
    FILE *fin = fopen(argv[1], "r");
    FILE *fout = fopen(argv[2], "w");
    int N,M,X,i;
    fscanf(fin,"%d%d%d", &N,&M,&X);
    int movei[4] = {-1,1,0,0};
    int movej[4] = {0,0,-1,1};
    int *moves = malloc(X*sizeof(int));
    int pozi, pozj;
    int **matrix = create_matrix(N, M, &pozi, &pozj, fin);
    int contor = 0;
    for (i = 0; i < X; i++) {
        fscanf(fin,"%d",&moves[i]);
    }
    dfs(N, M, pozi, pozj, matrix, 0, X, moves, movei, movej, &contor);
    printf("%d\n",contor);
    fclose(fin);
    fclose(fout);
}