#include <stdlib.h>
#include <stdio.h>

int **init_matrix(int N, int M);
int **create_matrix(int N, int M, int *pozi, int *pozj, FILE *file);
void dfs(int N, int M, int pozi, int pozj, int **matrix, int idx_move, int max_moves, int *moves, int *movei, int *movej, int *cnt);