#include <stdlib.h>
#include <stdio.h>
#include "graph1.h"

int main(int argc, char **argv)
{
    // FILE *fin=fopen("schimbare.in","r");
    // FILE *fout=fopen("schimbare.out","w");
    FILE *fin=fopen(argv[1],"r");
    FILE *fout=fopen(argv[2],"w");
    Graph *graph_dir = malloc(sizeof(Graph));
    Graph *graph_undir = malloc(sizeof(Graph));
    int i, nodes, edges, mincost = 2000000000;
    fscanf(fin,"%d %d",&nodes ,&edges);
    initGraphs(nodes,edges,graph_dir,graph_undir,fin);
    int *parents = calloc((nodes + 1), sizeof(int));
    int *vizitat = calloc((nodes + 1), sizeof(int));
    parents[1]=0;
    vizitat[1]=1;
    for (i = 1; i <= nodes; i++) {
        if(graph_undir->adj[i][0].n==1) {
            continue;
        }
        dfs(graph_dir, graph_undir, i, &mincost, parents, vizitat);
        break;
    }
    if( mincost == 2000000000) {
        fprintf(fout,"-1\n");
    }
    else {
        fprintf(fout,"%d\n",mincost);
    }
    freeGraph(nodes,graph_dir);
    freeGraph(nodes,graph_undir);
    free(parents);
    free(vizitat);
    fclose(fout);
    fclose(fin);
}