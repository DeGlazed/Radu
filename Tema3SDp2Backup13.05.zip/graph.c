#include <stdlib.h>
#include <stdio.h>
#include "graph.h"
#include "heap.h"

Graph *initGraph(int nodes, int edges, FILE *file)
{
    Graph *graph = malloc(sizeof(Graph));
    graph->adj = buildGraph(nodes,edges,file);
    graph->no_nodes = nodes;
    return graph;
}

Edge **buildGraph(int nodes, int edges, FILE *file)
{
    int i, s, d, w;
    Edge **adj= malloc((nodes + 1) * sizeof(Edge *));
    adj[0] = malloc((nodes + 1) * sizeof(Edge));
    for (i = 1; i <= nodes; i++) {
        adj[i] = malloc((nodes + 1) * sizeof(Edge));
        //pozitia de 0 o voi folosi ca un contor de vecini ai nodului i
        //vecinii vor fi de la 1 incolo
        //numarul de vecini va fi contorizar de la 1
        //(nr de vecin = 1 => nu ai niciun vecin)
        adj[i][0].n = 1;
		adj[i][0].w = 0;
    }
    for (i = 0; i < edges; i++) {
        fscanf(file, "%d %d %d\n", &s, &d, &w);
        adj[s][adj[s][0].n].n = d;
        adj[s][adj[s][0].n].w = w;
        adj[s][0].n++;

        adj[d][adj[d][0].n].n = s;
        adj[d][adj[d][0].n].w = w;
        adj[d][0].n++;
    }
    return adj;
}

void freeEdges(int nodes, Edge **adj)
{
    int i;
    for ( i=0; i < nodes; i++){
        free(adj[i]);
    }
    free(adj);
}

void freeGraph(int nodes, Graph *graph)
{
    freeEdges(nodes, graph->adj);
    free(graph);
}

//algoritmul lui Dijkstra pe care l-am facut la laborator, cu heap-uri
void dijkstra(Graph *graph, int nod, int *cost_final, int *rep)
{
    Heap *heap = initheap(graph->no_nodes);
    int *parents = malloc((graph->no_nodes + 1) * sizeof(int));
    int *dist = malloc((graph->no_nodes + 1) * sizeof(int));
    int i;
    int start = nod;
    parents[nod]=0;
    dist[nod]=0;
    cost_final[nod]=0;
    rep[nod] = nod;
    insert_data(heap,dist[nod], nod);
    for (i = 1; i <= graph->no_nodes; i++) {
        if (i != nod) {
            parents[i] = 0;
            dist[i] = 2000000000; //infinit
            insert_data(heap,dist[i],i);
        }
    }
    while (isEmptyHeap(heap) == 0) {
        nod = extract_data(heap);
        for (i = 1; i < graph->adj[nod][0].n; i++) {
            if (inHeap(heap,graph->adj[nod][i].n) && dist[nod] != 2000000000 && graph->adj[nod][i].w + dist[nod] < dist[graph->adj[nod][i].n]) {
                parents[graph->adj[nod][i].n] = nod;
                dist[graph->adj[nod][i].n] = dist[nod] + graph->adj[nod][i].w;
                decreasePriority(heap, dist[graph->adj[nod][i].n],graph->adj[nod][i].n);
                //--------------------------
                if(cost_final[graph->adj[nod][i].n] > dist[graph->adj[nod][i].n]) {
                    cost_final[graph->adj[nod][i].n] = dist[graph->adj[nod][i].n];
                    rep[graph->adj[nod][i].n] = start;
                }
                else if(cost_final[graph->adj[nod][i].n] == dist[graph->adj[nod][i].n]) {
                    if(rep[graph->adj[nod][i].n] > start) {
                        rep[graph->adj[nod][i].n] = start;
                    }
                }
            }
        }
    }
    //debug dijkstra
    // for (i = 1; i <= graph->no_nodes; i++) {
	// 	printf("%d (%d): ", i, dist[i]);
	// 	printf("\n");
	// }
	// printf("\n");
    free(parents);
    free(dist);
    freeHeap(heap);
}
// for debug
void print_graf(Graph *graph)
{
    int i, j;
    for (i = 1; i <= graph->no_nodes; i++) {
        printf("%d : ",i);
        for (j = 1; j < graph->adj[i][0].n; j++) {
            printf("%d(%d) ",graph->adj[i][j].n,graph->adj[i][j].w);
        }
        printf("\n");
    }
}

void procesare(Graph *graph, int *rep, int nr_rep, FILE *file)
{
    int i;
    int *cost_final = calloc((graph->no_nodes + 1), sizeof(int));
    for (i = 1; i <=graph->no_nodes; i++) {
        cost_final[i]=2000000000;
    }
    int *rep_final = calloc((graph->no_nodes + 1), sizeof(int));
    for (i = 0; i < nr_rep; i++) {
        dijkstra(graph, rep[i], cost_final, rep_final);
    }
    for(i = 1; i <= graph->no_nodes; i++) {
        if( cost_final[i] == 2000000000) {
            fprintf(file,"-1\n");
        }
        else {
            fprintf(file,"%d %d\n",rep_final[i],cost_final[i]);
        }
    }
    free(cost_final);
    free(rep_final);
}