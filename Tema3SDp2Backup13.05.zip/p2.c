#include <stdlib.h>
#include <stdio.h>
#include "graph.h"
#include "heap.h"

int main(int argc, char **argv)
{
    FILE *fin = fopen(argv[1],"r");
    FILE *fout = fopen(argv[2],"w");
    int nr_noduri,nr_muchii,i,x;
    fscanf(fin,"%d%d%d",&nr_noduri,&nr_muchii,&x);
    Graph *graph = initGraph(nr_noduri,nr_muchii,fin);
    int *rep=malloc(x * sizeof(int));
    for (i = 0; i < x; i++){
        fscanf(fin, "%d",&rep[i]);
    }
    procesare(graph,rep,x,fout);
    freeGraph(graph->no_nodes,graph);
    fclose(fin);
    fclose(fout);
    return 0;
}