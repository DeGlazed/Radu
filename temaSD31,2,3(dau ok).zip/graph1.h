#include <stdlib.h>
#include <stdio.h>

typedef struct edge{
    int n;
    int w;
}Edge;

typedef struct graph{
    int no_nodes;
    Edge **adj;
}Graph;

void initGraphs(int nodes, int edges, Graph *graph_dir, Graph *graph_undir, FILE *file);
void buildGraphs(int nodes, int edges, Edge **adj_dir, Edge **adj_undir, FILE *file);
void freeEdges(int nodes, Edge **adj);
void freeGraph(int nodes, Graph *graph);
void print_graf(Graph *graph);
void dfs(Graph *graph_dir, Graph *graph_undir, int nod, int *mincost,int *parents, int* vizitat);
void compute_cost(Graph *graph_dir, int nod_inc, int nod_fin, int *mincost,int *parents);
int exists_arch(Graph *graph_dir, int p, int n);