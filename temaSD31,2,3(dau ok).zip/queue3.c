#include <stdlib.h>
#include <stdio.h>
#include "queue3.h"

Node *initNode(int data)
{
    //initializeaza nodurile
    Node *node = malloc(sizeof(Node));
    node->val = data;
    node->next = NULL;
    node->prev = NULL;
    return node;
}

Queue *initQueue()
{
    //initializeaza coada
    Queue *queue = malloc(sizeof(Queue));
    queue->size = 0;
    queue->tail = NULL;
    queue->head = NULL;
    return queue;
}

int isEmpty(Queue *queue)
{
    //verifica daca coada este goala sau nu
    if (queue->tail == NULL || queue->head == NULL) {
        return 1;
    }
    else {
        return 0;
    }  
}

//operatii cozi
void enque(Queue *queue, int data)
{
    Node *node = initNode(data);
    if (isEmpty(queue)) {
        queue->head = node;
        queue->tail = node;
    }
    else {
        queue->tail->next = node;
        node->prev = queue->tail;
        queue->tail = node;
    }
    queue->size++;
}

int deque(Queue *queue)
{
    Node *node;
    int val;
    if (isEmpty(queue)) {
        val=-1;
    }
    else {
        node = queue->head;
        val = node->val;
        queue->head = queue->head->next;
        //daca e goala da seg fault daca fac atribuirea din if
        if(isEmpty(queue) == 0) {
            queue->head->prev=NULL;
        }
        freeNode(node);
        queue->size -= 1;
    }
    return val;
}

//free-uri
void freeNode(Node *node)
{
    free(node);
}

void freeQueue(Queue *queue)
{
    while(isEmpty(queue) == 0) {
        deque(queue);
    }
    free(queue);
}
