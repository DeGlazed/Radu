#include <stdlib.h>
#include <stdio.h>
#include "graph1.h"

void initGraphs(int nodes, int edges, Graph *graph_dir, Graph *graph_undir, FILE *file)
{
    graph_dir->adj= malloc((nodes + 1) * sizeof(Edge *));
    graph_undir->adj= malloc((nodes + 1) * sizeof(Edge *));
    buildGraphs(nodes,edges, graph_dir->adj,graph_undir->adj,file);
    graph_dir->no_nodes = nodes;
    graph_undir->no_nodes = nodes;
}

void buildGraphs(int nodes, int edges, Edge **adj_dir, Edge **adj_undir, FILE *file)
{
    int i, s, d, w;
    adj_dir[0] = malloc((nodes + 1) * sizeof(Edge));
    adj_undir[0] = malloc((nodes + 1) * sizeof(Edge));
    for (i = 1; i <= nodes; i++) {
        adj_dir[i] = malloc((nodes + 1) * sizeof(Edge));
        adj_undir[i] = malloc((nodes + 1) * sizeof(Edge));
        //pozitia de 0 o voi folosi ca un contor de vecini ai nodului i
        //vecinii vor fi de la 1 incolo
        //numarul de vecini va fi contorizar de la 1
        //(nr de vecin = 1 => nu ai niciun vecin)
        adj_dir[i][0].n = 1;
		adj_dir[i][0].w = 0;
        adj_undir[i][0].n = 1;
		adj_undir[i][0].w = 0;
    }
    for (i = 0; i < edges; i++) {
        fscanf(file, "%d %d %d\n", &s, &d, &w);
        adj_dir[s][adj_dir[s][0].n].n = d;
        adj_dir[s][adj_dir[s][0].n].w = w;
        adj_dir[s][0].n++;

        adj_undir[s][adj_undir[s][0].n].n = d;
        adj_undir[s][adj_undir[s][0].n].w = 0;
        adj_undir[s][0].n++;

        adj_undir[d][adj_undir[d][0].n].n = s;
        adj_undir[d][adj_undir[d][0].n].w = 0;
        adj_undir[d][0].n++;
    }
}

void freeEdges(int nodes, Edge **adj)
{
    int i;
    for ( i=0; i < nodes; i++){
        free(adj[i]);
    }
    free(adj);
}

void freeGraph(int nodes, Graph *graph)
{
    freeEdges(nodes, graph->adj);
    free(graph);
}

void print_graf(Graph *graph)
{
    int i, j;
    for (i = 1; i <= graph->no_nodes; i++) {
        printf("%d : ",i);
        for (j = 1; j < graph->adj[i][0].n; j++) {
            printf("%d(%d) ",graph->adj[i][j].n,graph->adj[i][j].w);
        }
        printf("\n");
    }
}

void dfs(Graph *graph_dir, Graph *graph_undir, int nod, int *mincost,int *parents, int* vizitat)
{
    int i;
    for( i = 1; i < graph_undir->adj[nod][0].n; i++) {
        int child = graph_undir->adj[nod][i].n;
        if ( vizitat[child] == 1 && parents[nod] != child ) {
            //calculeaza cost
            compute_cost(graph_dir, child, nod, mincost, parents);
            return;
        }
        else if ( vizitat[child] == 1 && parents[nod] == child ) {
            continue;
        }
        else {
            vizitat[child] = 1;
            parents[child] = nod;
            dfs(graph_dir, graph_undir, child, mincost, parents, vizitat);
            vizitat[child] = 0;
            parents[child] = 0;
        }
    }

}

void compute_cost(Graph *graph_dir, int nod_inc, int nod_fin, int *mincost, int *parents)
{
    //printf("start comupte\n");
    int cost1 = 0, cost2 = 0;
    int n, p, index;
    n = nod_fin;
    while (n != nod_inc) {
        p = parents[n];
        //daca exista arc de la p la n
        index = exists_arch(graph_dir,p,n);
        if (index != 0) {
            cost2 += graph_dir->adj[p][index].w;
        }
        else {
            index = exists_arch(graph_dir,n,p);
            cost1 += graph_dir->adj[n][index].w;
        }
        //printf("n = %d, p = %d, cost1 = %d, cost2 = %d\n",n,p,cost1,cost2);
        n=p;
    }
    n=nod_inc;
    p=nod_fin;
    index = exists_arch(graph_dir,p,n);
    if (index != 0) {
        cost2 += graph_dir->adj[p][index].w;
    }
    else {
        index = exists_arch(graph_dir,n,p);
        cost1 += graph_dir->adj[n][index].w;
    }
    //printf("n = %d, p = %d, cost1 = %d, cost2 = %d\n",n,p,cost1,cost2);
    if (cost1 < *mincost) {
        *mincost = cost1;
    }
    if (cost2 < *mincost) {
        *mincost = cost2;
    }
    //printf("mincost = %d",*mincost);
    //printf("end comupte\n");
}

int exists_arch(Graph *graph_dir, int p, int n)
{
    int i;
    for( i = 1; i < graph_dir->adj[p][0].n; i++) {
        if (graph_dir->adj[p][i].n == n) {
            return i;
        }
    }
    return 0;
}