#include <stdlib.h>
#include <stdio.h>
#include "heap2.h"

//init functions
Heap *initheap(int maxsize)
{
    Heap *heap = malloc(sizeof(Heap));
    heap->size = 0;
    heap->capacity = maxsize;
    heap->index = malloc(maxsize * sizeof(int));
    heap->nodes = malloc(maxsize * sizeof(HeapNode));
    return heap;
}

//utile
int isEmptyHeap(Heap *heap)
{
    if (heap->size == 0) {
        return 1;
    }
    else {
        return 0;
    }
}

int inHeap(Heap *heap, int data) //verifica daca elementul dat este in heap
{
    if (heap->index[data] < heap->size) {
        return 1;
    }
    else {
        return 0;
    }
}

int parent(int x) //intoarce adresa parintelui el. cu indecele x in heap
{
    return (x - 1) / 2;
}

int leftchild(int x)//intoarce indexul copilului stang al el. cu indicele x
{
    return 2 * x + 1;
}

int rightchild(int x)//intoarce indexul copilului drept al el. cu inicele x
{
    return 2 * x + 2;
}

// voia avea nevoie sa schimb atat tipuri int (heap->index), dar si tiputi HeapNode
// aceasta functie am luat-o direct din laboratorul de SD 
void swap(void *a, void *b, size_t len)
{
    size_t i;
    unsigned char *p = a, *q = b, tmp;
    for (i = 0; i != len; i++)
    {
        tmp = p[i];
        p[i] = q[i];
        q[i] = tmp;
    }
}

void siftUp(Heap *heap, int index)
{
    int par;
    par = parent(index);

    if( index > 0 && heap->nodes[par].priroritate > heap->nodes[index].priroritate) {
        swap(&heap->index[heap->nodes[par].val],&heap->index[heap->nodes[index].val], sizeof(int));
        swap(&heap->nodes[par],&heap->nodes[index],sizeof(HeapNode));
        //printf("merg swap-urile\n");//--------------------------------------------------------
        siftUp(heap, par);
    }

}

void siftDown(Heap *heap, int index)
{
    int left,right,dest; //index stanga, index dreata, indexul inde va trebui sa fie pus
    left = leftchild(index);
    right = rightchild(index);
    dest = index;
    if (left < heap->size && heap->nodes[left].priroritate < heap->nodes[dest].priroritate) {
        dest = left;
    }
    if (right < heap->size && heap->nodes[right].priroritate < heap->nodes[dest].priroritate) {
        dest = right;
    }
    if(dest != index) {
        swap(&heap->index[heap->nodes[dest].val], &heap->index[heap->nodes[index].val], sizeof(int));
        swap(&heap->nodes[dest], &heap->nodes[index], sizeof(HeapNode));
        //printf("merg swap-urile\n");//--------------------------------------------------------------------------
        siftDown(heap, dest);
    }
}

int extract_data(Heap *heap)
{
    int data;
    if (isEmptyHeap(heap)) {
        return -1;
    }
    data = heap->nodes[0].val;
    heap->index[data] = heap->size - 1; //ca si cum as "goli" acel index (il marchez ca inexistent, setand-ul la indexul maxim)
    heap->index[heap->nodes[heap->size - 1].val] = 0;// setez indexul ultimului element ca fiind primul element
    heap->nodes[0] = heap->nodes[heap->size - 1]; // aduc ultimul element pe priul loc
    heap->size--;
    siftDown(heap,0);
    return data;
}

void insert_data(Heap *heap, int prioritate, int data)
{
    //daca heap-ul e full
    if(heap->size == heap->capacity) {
        return;
    }
    heap->index[data] = heap->size; //setez idexul datei ca fiind ultimul element
    heap->nodes[heap->size].priroritate = prioritate;
    heap->nodes[heap->size].val = data;
    heap->size++;
    siftUp(heap,heap->size - 1);
}

//functie luata din laborator
//micsoreaza prioritatea unui element din heap (pentru dijkstra)
void decreasePriority(Heap *heap, int prioritate, int data)
{
    int index;
    index = heap->index[data];
    if (heap->nodes[index].priroritate <= prioritate) {
        return;
    }
    else {
        heap->nodes[index].priroritate = prioritate;
        siftUp(heap,index);
    }
}

void print_heap(Heap *heap)
{
    int i;
    for (i = 0;i < heap->size; i++){
        printf("%d(%d), ",heap->nodes[i].val,heap->nodes[i].priroritate);
    }
    printf("\n");
}

//free
void freeHeap(Heap *heap)
{
    free(heap->nodes);
    free(heap);
}
