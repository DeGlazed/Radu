#include <stdlib.h>
#include <stdio.h>
#include "graph3.h"
#include "queue3.h"

Graph *initGraph(int nodes, int edges, FILE *file)
{
    Graph *graph = malloc(sizeof(Graph));
    graph->adj = buildGraph(nodes,edges,file);
    return graph;
}

Edge **buildGraph(int nodes, int edges, FILE *file)
{
    int i;
    Edge **adj= malloc((nodes + 1) * sizeof(Edge *));
    adj[0] = malloc((nodes + 1) * sizeof(int));
    for (i = 1; i <= nodes; i++) {
        adj[i] = malloc((nodes + 1) * sizeof(int));
        adj[i][0].n = 1; 
        //pozitia de 0 o voi folosi ca un contor de vecini ai nodului i
        //vecinii vor fi de la 1 incolo
        //numarul de vecini va fi contorizar de la 1
        //(nr de vecin = 1 => nu ai niciun vecin)
    }
    for (i = 0; i < edges; i++) {
        int s, d; // sursa si destinatie; citesc laturile si le pun in graf
        fscanf(file, "%d%d", &s, &d);
        adj[s][adj[s][0].n].n=d;
        adj[s][0].n++;
        adj[d][adj[d][0].n].n=s;
        adj[d][0].n++;
    }
    return adj;
}

void freeEdges(int nodes, Edge **adj)
{
    int i;
    for ( i=0; i < nodes; i++){
        free(adj[i]);
    }
    free(adj);
}

void freeGraph(int nodes, Graph *graph)
{
    freeEdges(nodes, graph->adj);
    free(graph);
}
// for debug
void print_graf(int nodes, Graph *graph)
{
    int i, j;
    for (i = 1; i <= nodes; i++) {
        printf("%d : ",i);
        for(j = 1; j < graph->adj[i][0].n; j++) {
            printf("%d ",graph->adj[i][j].n);
        }
        printf("\n");
    }
}

void bfs(Graph *graph, int nodes, int nod_inceput, int nod_final, int *etichete, int *maxdepth)
{
    Queue *queue = initQueue();
    int *vizitat = calloc((nodes+1),sizeof(int));
    vizitat[nod_inceput] = 1;
    int val, i, k=0;
    etichete[nod_inceput]=k;
    enque(queue,nod_inceput);
    while (isEmpty(queue) == 0) {
        val=deque(queue);
        if(etichete[val] > k) {
            k=etichete[val];
        }
        for (i = 1; i < graph->adj[val][0].n; i++) {
            if (vizitat[graph->adj[val][i].n] == 0) {
                vizitat[graph->adj[val][i].n] = 1;
                etichete[graph->adj[val][i].n]=k+1;
                enque(queue, graph->adj[val][i].n);
                if(val == nod_final) {
                    *maxdepth=etichete[val];
                    return;
                }
            }
        }
        if(val == nod_final) {
            *maxdepth=etichete[val];
            return;
        }
    }
    freeQueue(queue);
    free(vizitat);
}

void dfs(Graph *graph, int nodes, int nod, int nod_fin, int *etichete, int *aparitii, int *parinti, int maxdepth)
{
    int i,n;
    if(etichete[nod] == maxdepth ) {
        if(nod == nod_fin) {
            n=nod;
            aparitii[n] += 1;
            while(parinti[n] != 0) {
                aparitii[parinti[n]] += 1;
                n=parinti[n];
            }
        }
    }
    else {
        for (i = 1; i < graph->adj[nod][0].n; i++) {
            if (etichete[nod] < etichete[graph->adj[nod][i].n]) {
                parinti[graph->adj[nod][i].n]=nod;
                dfs(graph,nodes,graph->adj[nod][i].n,nod_fin,etichete,aparitii,parinti,maxdepth);
                parinti[graph->adj[nod][i].n]=0;
            }
        }
    }
}

void proces(Graph *graph, int nodes, int nod_inc, int nod_fin, FILE *file)
{
    int *etichete = calloc((nodes + 1),sizeof(int));
    int *aparitii = calloc((nodes + 1),sizeof(int));
    int *parinti = calloc((nodes + 1),sizeof(int));
    int maxdepth=0,i,count=0;;
    bfs(graph, nodes, nod_inc, nod_fin, etichete, &maxdepth);
    dfs(graph, nodes, nod_inc, nod_fin, etichete, aparitii, parinti, maxdepth);
    if(maxdepth == 0){
        fprintf(file,"0");
        return;
    }
    for (i = 1; i <= nodes; i++) {
        if(aparitii[i] == aparitii[nod_inc]) {
            count++;
        }
    }
    fprintf(file,"%d ",count);
    for (i = 1; i <= nodes; i++) {
        if(aparitii[i] == aparitii[nod_inc]) {
            fprintf(file,"%d ",i);
        }
    }
    free(etichete);
    free(aparitii);
    free(parinti);
}

int all_visited(int nodes, int *visited)
{
    int i;
    for(i = 1; i <= nodes; i++) {
        if (visited[i] == 0)
            return 0;
    }
    return 1;
}