function [A, b] = generate_probabilities_system(rows)
  A=zeros(rows,rows);
  b=zeros(1,rows);
  A(1,1)=4;
  A(1,2)=-1;
  A(1,3)=-1;
  b(1)=0;
  el=2;
  for r=2:rows-1
    A(el,el)=5;
    A(el,el+1)=-1;
    A(el,el+r)=-1;
    A(el,el+r+1)=-1;
    b(el)=0;
    el=el+1;
    for i=2:r-1
      A(el,el)=6;
      A(el,el+1)=-1;
      A(el,el+r)=-1;
      A(el,el+r+1)=-1;
      b(el)=0;
      el=el+1;
    endfor
    A(el,el)=5;
    A(el,el+r)=-1;
    A(el,el+r+1)=-1;
    b(el)=0
    el=el+1;
  endfor
  A(el,el)=4;
  A(el,el+1)=-1;
  b(el)=1;
  for i=el+1:el+rows-2
    A(i,i)=5;
    A(i,i+1)=-1;
    b(i)=1;
  endfor
  A(el+rows-1,el+rows-1)=4;
  b(el+rows-1)=1;
  
  D=diag(diag(A));
  A=A+(A-D)';
  b=b';
endfunction