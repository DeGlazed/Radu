function [sol] = rgbHistogram(path_to_image, count_bins)
  
  A=imread(path_to_image);
  n=3*count_bins;
  sol=zeros(1,3*count_bins);
  h_R=zeros(1,count_bins+1);
  h_G=zeros(1,count_bins+1);
  h_B=zeros(1,count_bins+1);
 
  R=A(:,:,1);
  G=A(:,:,2);
  B=A(:,:,3);
  
  pas=256/count_bins;
  edges=[0:pas:256];
  [x,y]=size(R);
  
  for i=1:x
    h_R=h_R+histc(R(i,:),edges);
    h_G=h_G+histc(G(i,:),edges);
    h_B=h_B+histc(B(i,:),edges);
  endfor
  h_R=h_R(1,1:count_bins);
  h_G=h_G(1,1:count_bins);
  h_B=h_B(1,1:count_bins);
  sol=[h_R,h_G,h_B];
end