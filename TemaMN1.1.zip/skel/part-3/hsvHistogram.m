function [sol] = hsvHistogram(path_to_image, count_bins)
  
  A=imread(path_to_image);
  n=3*count_bins;
  sol=zeros(1,3*count_bins);
  h_H=zeros(1,count_bins+1);
  h_S=zeros(1,count_bins+1);
  h_V=zeros(1,count_bins+1);
  
  R=A(:,:,1);
  G=A(:,:,2);
  B=A(:,:,3);
  
  [H,S,V]=RGB_to_HSV(R,G,B);
  
  %pasH=(361/count_bins)/360;
  pasH=1.01;
  pas=(101/count_bins)/100;
  H=H*count_bins;
  
  edgesH=[0:pasH:count_bins+1];
  edges=[0:pas:101/100];
  [x,y]=size(H);
  
  %V=V*100;
  %S=S*100;
  
  for i=1:x
    h_H=h_H+histc(H(i,:),edgesH);
    h_S=h_S+histc(S(i,:),edges);
    h_V=h_V+histc(V(i,:),edges);
  endfor
  
  h_H=h_H(1,1:count_bins);
  h_S=h_S(1,1:count_bins);
  h_V=h_V(1,1:count_bins);
  sol=[h_H,h_S,h_V];
end