function [percentage] = evaluate(path_to_testset, w, histogram, count_bins)
  
  h=strfind(histogram,"RGB"); 
  
  path_no_cats=[path_to_testset "not_cats/"];
  path_cats=[path_to_testset "cats/"];
  
  img_cats=getImgNames(path_cats);
  img_no_cats=getImgNames(path_no_cats);
  
  [n,m]=size(img_cats);
  for i=1:n
    mat_path_cats(i,:)=[path_cats img_cats(i,:)];
  endfor
  
  [a,m]=size(img_no_cats);
  for i=1:a
    mat_path_no_cats(i,:)=[path_no_cats img_no_cats(i,:)];
  endfor
  
  [n,m]=size(mat_path_cats);
  [a,m]=size(mat_path_no_cats);
  
  X=zeros(n+a,3*count_bins);
  for i=1:n
    if h==1
      X(i,:)=rgbHistogram(mat_path_cats(i,:),count_bins);
    else
      X(i,:)=hsvHistogram(mat_path_cats(i,:),count_bins);
    endif
  endfor
  
  for i=1:a
    if h==1
      X(i+n,:)=rgbHistogram(mat_path_no_cats(i,:),count_bins);
    else
      X(i+n,:)=hsvHistogram(mat_path_no_cats(i,:),count_bins);
    endif
  endfor
  w=w(1:3*count_bins);
  y=(w')*X';
  [n,m]=size(y);
  cnt=0;
  for i=1:m
    if y(i)>=0
      cnt++;
    endif
  endfor
  
  percentage=100-(cnt/m)*100;
endfunction