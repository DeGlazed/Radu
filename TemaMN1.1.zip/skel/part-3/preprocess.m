function [X, y] = preprocess(path_to_dataset, histogram, count_bins)
  
  h=strfind(histogram,"RGB");  
  
  path_no_cats=[path_to_dataset "not_cats/"];
  path_cats=[path_to_dataset "cats/"];
  
  img_cats=getImgNames(path_cats);
  img_no_cats=getImgNames(path_no_cats);
  
  [n,m]=size(img_cats);
  for i=1:n
    mat_path_cats(i,:)=[path_cats img_cats(i,:)];
  endfor
  
  [a,m]=size(img_no_cats);
  for i=1:a
    mat_path_no_cats(i,:)=[path_no_cats img_no_cats(i,:)];
  endfor
  
  [n,m]=size(mat_path_cats);
  [a,m]=size(mat_path_no_cats);
  
  X=zeros(n+a,3*count_bins);
  y=ones(n+a,1);
  y(n+1:n+a,1)=y(n+1:n+a,1)*(-1);
  
  for i=1:n
    if h==1
      X(i,:)=rgbHistogram(mat_path_cats(i,:),count_bins);
    else
      X(i,:)=hsvHistogram(mat_path_cats(i,:),count_bins);
    endif
  endfor
  
  for i=1:a
    if h==1
      X(i+n,:)=rgbHistogram(mat_path_no_cats(i,:),count_bins);
    else
      X(i+n,:)=hsvHistogram(mat_path_no_cats(i,:),count_bins);
    endif
  endfor
  
endfunction
