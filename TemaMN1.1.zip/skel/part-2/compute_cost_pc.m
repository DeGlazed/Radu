function [cost] = compute_cost_pc(points, centroids)
  [NC,n]=size(centroids);
  [N,n]=size(points);
  cost=0;
  for i=1:N
    min=inf;
    for j=1:NC
      D=norm(points(i,:)-centroids(j,:));
      if D<min
        min=D;
      endif
    endfor
    cost=cost+min;
  endfor
endfunction

