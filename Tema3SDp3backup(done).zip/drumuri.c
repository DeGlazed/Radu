#include <stdlib.h>
#include <stdio.h>
#include "graph.h"



int main(int argc, char **argv)
{
    FILE *fin = fopen(argv[1],"r");
    FILE *fout = fopen(argv[2], "w");
    // FILE *fin = fopen("drumuri.in","r");
    // FILE *fout = fopen("drumuri.out", "w");
    int nodes, edges, no_query, i, nod_plecare, nod_destinatie;
    fscanf(fin, "%d%d%d", &nodes, &edges, &no_query);
    Graph *graph = initGraph(nodes, edges, fin);
    //print_graf(nodes, graph);
    for (i = 0; i < no_query; i++) {
        // //-----------------------------
        // printf("query %d:\n",i);//debug
        // //-----------------------------
        fscanf(fin, "%d%d", &nod_plecare, &nod_destinatie);
        //parcurgere(nod_plecare, nod_destinatie, nodes, graph, fout);
        proces(graph, nodes, nod_plecare, nod_destinatie, fout);
        fprintf(fout,"\n");
        // printf("\n");
    }
    return 0;
}